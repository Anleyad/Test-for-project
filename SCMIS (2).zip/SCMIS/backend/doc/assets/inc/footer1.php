<footer class="footer footer-alt">
            2015 - <?php echo date ('Y');?> &copy; Smart Care Medical Information System. Developed By 2015 Summer Graduate Students</a> 
</footer>