<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2015 - <?php echo date('Y'); ?> &copy; Smart Care Medical Information System. Developed By 2015 Summer Graduate Students</a>
            </div>

        </div>
    </div>
</footer>